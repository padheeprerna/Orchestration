jQuery(function ($) {
    var download_button = $('#configuration-download');

    // Create a blob object.
    var bb = new Blob(
        ["---\ndom:\n  engine: chrome\n  local_storage: {}\n  session_storage: {}\n  wait_for_elements: {}\n  pool_size: 4\n  job_timeout: 60\n  worker_time_to_live: 250\n  wait_for_timers: false\nsession: {}\ndevice:\n  visible: false\n  width: 1600\n  height: 1200\n  user_agent: Mozilla/5.0 (Gecko) SCNR::Engine/v1.0dev\n  pixel_ratio: 1.0\n  touch: false\ntimeout: {}\naudit:\n  parameter_values: true\n  paranoia: medium\n  exclude_vector_patterns: []\n  include_vector_patterns: []\n  link_templates: []\n  links: true\n  forms: true\n  cookies: true\n  ui_inputs: true\n  ui_forms: true\n  jsons: true\n  xmls: true\ndatastore: {}\nscope:\n  directory_depth_limit: 4\n  auto_redundant_paths: 2\n  redundant_path_patterns: {}\n  dom_depth_limit: 3\n  dom_event_limit: 500\n  dom_event_inheritance_limit: 500\n  exclude_file_extensions:\n  - css\n  - png\n  exclude_path_patterns: []\n  exclude_content_patterns: []\n  include_path_patterns:\n  - 172.31.3.192\n  restrict_paths: []\n  extend_paths: []\n  url_rewrites: {}\ninput:\n  values: {}\n  default_values:\n    name: scnr_engine_name\n    user: scnr_engine_user\n    usr: scnr_engine_user\n    pass: 5543!%scnr_engine_secret\n    txt: scnr_engine_text\n    num: '132'\n    amount: '100'\n    mail: scnr_engine@email.gr\n    account: '12'\n    id: '1'\n  without_defaults: false\n  force: false\nhttp:\n  request_timeout: 20000\n  request_redirect_limit: 5\n  request_concurrency: 10\n  request_queue_size: 200\n  request_headers: {}\n  response_max_size: 10000\n  cookies: {}\n  authentication_type: auto\nchecks:\n- \"*\"\nplatforms:\n- linux\nplugins:\n  exec:\n    during: python /home/ubuntu/Orchestration/webapps/ThirdPartyTools.py 172.31.3.192\nno_fingerprinting: false\nauthorized_by: \nurl: http://172.31.3.192/DVWA/\n"],
        { type : 'application/yaml' }
    );

    download_button.attr( 'href', window.URL.createObjectURL( bb ) );
    download_button.attr( 'download', '172.31.3.192-profile.afp' );
});
